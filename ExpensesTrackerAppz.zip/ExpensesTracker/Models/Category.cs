﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ExpensesTracker.Models
{
    
    public class Category
    {
        [Key]
        public int CategoryId { get; set; }

        
        public string Title { get; set; } = null!;

        [Column(TypeName = "varchar(5)")]
        [Required(ErrorMessage = "Title is required.")]
        public string Icon { get; set; } = null!;

        [Column(TypeName = "varchar(10)")]
        public string Type { get; set; } = null!;//expenses

        [NotMapped]
        public string? TitleWithIcon
        {
            get
            {
                return this.Icon + " " + this.Title;
            }
        }
    }
}
